from odoo import models, fields, api


class Website(models.Model):
    _inherit = 'website'

    google_tags_manager = fields.Boolean("Google Tag Manager")
    container_id = fields.Char('Container Id')


class ResConfSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    google_tags_manager = fields.Boolean(related='website_id.google_tags_manager',
                                         config_parameter='google_tag_manager.google_tags_manager', readonly=False)
    container_id = fields.Char(related='website_id.container_id',
                               config_parameter='google_tag_manager.container_id',
                               readonly=False)
