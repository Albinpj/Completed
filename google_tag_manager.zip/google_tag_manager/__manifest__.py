{
    'name': 'Google Tag Manager',
    'version': '16.0.1.0.0',
    'summary': """The Google Tag Manager(GTM) Module Helps To Create And Add Tags For Your Website Shop. This Module Usefully For
        Analyze SEO""",
    'description': """The Google Tag Manager(GTM) Module Helps To Create And Add Tags For Your Website Shop. This Module Usefully For
        Analyze SEO""",
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'website': "https://www.cybrosys.com",
    'maintainer': 'Cybrosys Techno Solutions',
    'depends': ['base', 'contacts', 'website'],
    'data': [
        'views/website.xml',
        'views/google_tag_manager.xml'
    ],

    'license': 'LGPL-3',
    'price': 29,
    'currency': 'EUR',
    'installable': True,
    'auto_install': False,
    'application': False,
    'category': 'Website'
}
