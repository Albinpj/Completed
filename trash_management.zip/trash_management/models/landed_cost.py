from odoo import fields, models, api


class DeleteLandedCost(models.Model):
    _inherit = 'stock.landed.cost'
    _description = "Landed Cost Trash Management"

    def unlink(self):
        for rec in self:
            landed_cost_trash_id = self.env['landed.cost.trash'].create({
                'date': rec.date,
                'name': rec.name,
                'picking_ids': rec.picking_ids,
                'account_journal_id': rec.account_journal_id.id,
                'company_id': rec.company_id.id,
                'vendor_bill_id': rec.vendor_bill_id.id,
                'state': rec.state,

            })

            for rec_order_line in rec.cost_lines:
                landed_cost_trash_id.write({
                    'landed_cost_ids': [(0, 0, {
                        'product_id': rec_order_line.product_id.id,
                        'name': rec_order_line.name,
                        'account_id': rec_order_line.account_id.id,
                        'split_method': rec_order_line.split_method,
                        'price_unit': rec_order_line.price_unit,

                    })]
                })
        return super(DeleteLandedCost, self).unlink()


class LandedCostTrash(models.Model):
    _name = "landed.cost.trash"
    _description = "Landed Cost Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', readonly=True)
    date = fields.Datetime(string='Date', readonly=True)
    picking_ids = fields.Many2many('stock.picking', string="Transfers", readonly=True)
    account_journal_id = fields.Many2one('account.journal', string='Journal', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    vendor_bill_id = fields.Many2one('account.move', string='Vendor Bill', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Posted'),
        ('cancel', 'Cancelled')], string='State', readonly=True)
    landed_cost_ids = fields.One2many('landed.cost.trash.order.line', 'landed_cost_id', string="Landed Cost Order Line",
                                      readonly=True)

    @api.model
    def delete_landed_cost_trash(self):
        document = self.env['landed.cost.trash'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.landed_cost_clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_landed_cost(self):
        for rec in self:
            landed_cost_order_id = self.env['stock.landed.cost'].create({
                'date': rec.date,
                'name': rec.name,
                'picking_ids': rec.picking_ids,
                'account_journal_id': rec.account_journal_id.id,
                'company_id': rec.company_id.id,
                'vendor_bill_id': rec.vendor_bill_id.id,
                'state': rec.state,

            })
        for rec_order_line in self.landed_cost_ids:
            landed_cost_order_id.write({
                'cost_lines': [(0, 0, {
                    'product_id': rec_order_line.product_id.id,
                    'name': rec_order_line.name,
                    'account_id': rec_order_line.account_id.id,
                    'split_method': rec_order_line.split_method,
                    'price_unit': rec_order_line.price_unit,
                })]
            })

        rec.unlink()


class LandedCostOrderLine(models.Model):
    _name = "landed.cost.trash.order.line"

    product_id = fields.Many2one('product.product', string='Product')
    name = fields.Char('Description')
    account_id = fields.Many2one('account.account', string='Account')
    split_method = fields.Selection([
        ('equal', 'Equal'),
        ('by_quantity', 'By Quantity'),
        ('by_current_cost_price', 'By Current cost'),
        ('by_weight', 'By Weight'),
        ('by_volume', 'By Volume ')
    ], string='Split Method')
    price_unit = fields.Float(string='Cost')
    landed_cost_id = fields.Many2one('landed.cost.trash')


class LandedCostTrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    landed_cost_clear_trash = fields.Integer(config_parameter='trash_management.landed_cost_clear_trash')
