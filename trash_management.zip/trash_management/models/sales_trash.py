from odoo import fields, models, api


class DeleteRecords(models.Model):
    _inherit = 'sale.order'
    _description = "Sales Trash Management"

    def unlink(self):
        for rec in self:
            trash = self.env['trash.management'].create({
                'customer': rec.partner_id.id,
                'name': rec.name,
                'quotation_template': rec.sale_order_template_id.id,
                'date': rec.date_order,
                'pricelist_id': rec.pricelist_id.id,
                'payment_term': rec.payment_term_id.id,
                'state': rec.state,
                'origin': rec.origin,
                'user_id': rec.user_id.id,
                'team_id': rec.team_id.id,
                'customer_reference': rec.client_order_ref,
                'tags_ids': rec.tag_ids,
                'commitment_date': rec.commitment_date,
                'fiscal_position_id': rec.fiscal_position_id.id,
                'company_id': rec.company_id.id,
                'campaign_id': rec.campaign_id.id,
                'journal': rec.l10n_in_journal_id.id,
                'medium_id': rec.medium_id.id,
                'source_id': rec.source_id.id,
            })
            for rec_order_line in rec.order_line:
                trash.write({
                    'order_ids': [(0, 0, {
                        'product_id': rec_order_line.product_id.id,
                        'product_template_id': rec_order_line.product_template_id.id,
                        'quantity': rec_order_line.product_uom_qty,
                        'description': rec_order_line.name,
                        'unit_price': rec_order_line.price_unit,
                        'taxes_ids': rec_order_line.tax_id,
                        'sub_total': rec_order_line.price_subtotal,
                        'delivered': rec_order_line.qty_delivered,
                        'invoiced': rec_order_line.qty_invoiced,

                    })]
                })
        return super(DeleteRecords, self).unlink()


class TrashManagement(models.Model):
    _name = "trash.management"
    _description = "Sale Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    date = fields.Char(string="Order Date", readonly=True)
    today = fields.Date.today()
    name = fields.Char(string="Name", readonly=True)
    customer = fields.Many2one('res.partner', string="Customer", readonly=True)
    pricelist_id = fields.Many2one('product.pricelist', string="Pricelist", readonly=True)
    payment_term = fields.Many2one('account.payment.term', string="Payment Term", readonly=True)
    quotation_template = fields.Many2one('sale.order.template', string="Quotation Template", readonly=True)
    user_id = fields.Many2one('res.users', string="Sales Person", readonly=True)
    state = fields.Selection(
        [('draft', 'Quotation'), ('sent', 'Quotation Sent'), ('sale', 'Sale Order'), ('cancel', 'Cancelled')],
        readonly=True)
    order_ids = fields.One2many('trash.order.line', 'order_id', string="order lines", readonly=True)
    team_id = fields.Many2one('crm.team', string="Sales Team", readonly=True)
    company_id = fields.Many2one('res.company', string="Company", readonly=True)
    customer_reference = fields.Char(string="Customer Reference", readonly=True)
    tags_ids = fields.Many2many('crm.tag', string="Tags", readonly=True)
    fiscal_position_id = fields.Many2one('account.fiscal.position', string="Fiscal Position", readonly=True)
    journal = fields.Many2one('account.journal', string="Journal", readonly=True)
    origin = fields.Char(string="Source Document", readonly=True)
    campaign_id = fields.Many2one('utm.campaign', string="Campaign", readonly=True)
    medium_id = fields.Many2one('utm.medium', string="Medium", readonly=True)
    source_id = fields.Many2one('utm.source', string="Source", readonly=True)
    commitment_date = fields.Datetime(string="Delivery Date", readonly=True)

    @api.model
    def delete_trash(self):
        document = self.env['trash.management'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_sale_order(self):
        for rec in self:
            sale_order_id = self.env['sale.order'].create({
                'partner_id': rec.customer.id,
                'name': rec.name,
                'sale_order_template_id': rec.quotation_template.id,
                'date_order': rec.date,
                'pricelist_id': rec.pricelist_id.id,
                'payment_term_id': rec.payment_term.id,
                'state': rec.state,
                'origin': rec.origin,
                'user_id': rec.user_id.id,
                'team_id': rec.team_id.id,
                'client_order_ref': rec.customer_reference,
                'tag_ids': rec.tags_ids,
                'commitment_date': rec.commitment_date,
                'fiscal_position_id': rec.fiscal_position_id.id,
                'company_id': rec.company_id.id,
                'campaign_id': rec.campaign_id.id,
                'l10n_in_journal_id': rec.journal.id,
                'medium_id': rec.medium_id.id,
                'source_id': rec.source_id.id,
            })
        for rec_order_line in self.order_ids:
            sale_order_id.write({
                'order_line': [(0, 0, {
                    'product_id': rec_order_line.product_id.id,
                    'product_template_id': rec_order_line.product_template_id.id,
                    'product_uom_qty': rec_order_line.quantity,
                    'name': rec_order_line.description,
                    'price_unit': rec_order_line.unit_price,
                    'tax_id': rec_order_line.taxes_ids,
                    'price_subtotal': rec_order_line.sub_total,
                    'qty_delivered': rec_order_line.delivered,
                    'qty_invoiced': rec_order_line.invoiced,

                })]
            })
        rec.unlink()


class TrashOrderLine(models.Model):
    _name = "trash.order.line"

    order_id = fields.Many2one('trash.management')
    product_template_id = fields.Many2one(
        string="Product Template",
        related='product_id.product_tmpl_id')
    product_id = fields.Many2one(
        comodel_name='product.product',
        string="Product")
    description = fields.Char(string="Description")
    quantity = fields.Float(string="Quantity")
    delivered = fields.Float(string="Delivered")
    invoiced = fields.Float(string="Invoiced")
    unit_price = fields.Float(string="Unit Price")
    taxes_ids = fields.Many2many('account.tax', string="Taxes")
    sub_total = fields.Float(string="Sub Total")


class TrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    clear_trash = fields.Integer(config_parameter='trash_management.clear_trash')
