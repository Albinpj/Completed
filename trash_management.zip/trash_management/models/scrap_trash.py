from odoo import fields, models, api


class DeleteScrap(models.Model):
    _inherit = 'stock.scrap'
    _description = "Scrap Trash Management"

    def unlink(self):
        for rec in self:
            self.env['scrap.trash'].create({
                'name': rec.name,
                'product_id': rec.product_id.id,
                'scrap_qty': rec.scrap_qty,
                'package_id': rec.package_id.id,
                'location_id': rec.location_id.id,
                'scrap_location_id': rec.scrap_location_id.id,
                'origin': rec.origin,
                'date_done': rec.date_done,
                'company_id': rec.company_id.id,
                'state': rec.state,
            })
        return super(DeleteScrap, self).unlink()


class ScrapTrash(models.Model):
    _name = "scrap.trash"
    _description = "Scrap Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Reference', readonly=True)
    product_id = fields.Many2one('product.product', string='Product', readonly=True)
    scrap_qty = fields.Float(string='Quantity', readonly=True)
    package_id = fields.Many2one('stock.quant.package', string='Package', readonly=True)
    location_id = fields.Many2one('stock.location', string='Source Location', readonly=True)
    scrap_location_id = fields.Many2one('stock.location', string='Scrap Location', readonly=True)
    origin = fields.Char(string='Source Document', readonly=True)
    date_done = fields.Datetime(string='Date', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('done', 'Done')],
        string='Status', readonly=True)

    @api.model
    def delete_scrap_trash(self):
        document = self.env['scrap.trash'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.scrap_clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_scrap(self):
        for rec in self:
            self.env['stock.scrap'].create({
                'name': rec.name,
                'product_id': rec.product_id.id,
                'scrap_qty': rec.scrap_qty,
                'package_id': rec.package_id.id,
                'location_id': rec.location_id.id,
                'scrap_location_id': rec.scrap_location_id.id,
                'origin': rec.origin,
                'date_done': rec.date_done,
                'company_id': rec.company_id.id,
                'state': rec.state,
            })

        rec.unlink()


class ScrapTrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    scrap_clear_trash = fields.Integer(config_parameter='trash_management.scrap_clear_trash')
